﻿namespace WordleGameAPI.Models
{
    public class Guess
    {
        public int Id { get; set; }
        public int GameId { get; set; }
        public string? Word { get; set; }
        public int GuessNumber { get; set; }
        public string? GuessResult { get; set; }

        public Game? Game { get; set; }
    }
}
