﻿namespace WordleGameAPI.Models
{
    public class User
    {
        public int Id { get; set; }
        public string? Email { get; set; }
        public string? PasswordHash { get; set; }

        public ICollection<Game>? Games { get; set; }
        public Statistic? Statistic { get; set; }
    }
}
