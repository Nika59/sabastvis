﻿using Microsoft.EntityFrameworkCore;
using WordleGameAPI.Models;

namespace WordleGameAPI.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        public DbSet<User> Users => Set<User>();
        public DbSet<Game> Games => Set<Game>();
        public DbSet<Guess> Guesses => Set<Guess>();
        public DbSet<Statistic> Statistics => Set<Statistic>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure one-to-many: Game has many Guesses
            modelBuilder.Entity<Guess>()
                .HasOne(g => g.Game)
                .WithMany(game => game.Guesses)
                .HasForeignKey(g => g.GameId)
                .OnDelete(DeleteBehavior.Cascade); // Optional: cascade delete guesses when a game is deleted
        }
    }
}
