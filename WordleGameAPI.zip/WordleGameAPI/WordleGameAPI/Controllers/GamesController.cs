﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using WordleGameAPI.Data;
using WordleGameAPI.Models;

namespace WordleGameAPI.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class GamesController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public GamesController(ApplicationDbContext context)
        {
            _context = context;
        }

        private int GetUserId()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
            if (userIdClaim == null)
                throw new Exception("User ID claim missing");

            return int.Parse(userIdClaim.Value);
        }

        [HttpGet]
        public async Task<IActionResult> GetMyGames()
        {
            var userId = GetUserId();
            var games = await _context.Games
                .Where(g => g.UserId == userId)
                .ToListAsync();

            return Ok(games);
        }

        public class StartGameResponseDto
        {
            public int GameId { get; set; }
            public string Message { get; set; } = string.Empty;
        }

        public class GuessDto
        {
            public int GameId { get; set; }
            public string Word { get; set; } = string.Empty;
        }

        public class LetterStatusDto
        {
            public char Letter { get; set; }
            public string Status { get; set; } = string.Empty;
        }

        public class GuessResponseDto
        {
            public int GuessNumber { get; set; }
            public List<LetterStatusDto> LetterStatuses { get; set; } = new();
            public bool IsWin { get; set; }
            public bool IsGameOver { get; set; }
            public string Message { get; set; } = string.Empty;
        }

        private static readonly List<string> PossibleWords = new()
        {
            "apple", "bread", "crane", "drink", "eagle", "flame", "globe"
        };

        private string GetRandomWord()
        {
            var random = new Random();
            int index = random.Next(PossibleWords.Count);
            return PossibleWords[index];
        }

        [HttpPost("start")]
        public async Task<IActionResult> StartGame()
        {
            int userId = GetUserId();
            var targetWord = GetRandomWord();

            var game = new Game
            {
                UserId = userId,
                TargetWord = targetWord,
                StartDate = DateTime.UtcNow,
                EndDate = null,
                Attempts = 0,
                IsWin = false
            };

            _context.Games.Add(game);
            await _context.SaveChangesAsync();

            return Ok(new StartGameResponseDto
            {
                GameId = game.Id,
                Message = "New game started! Guess the 5-letter word."
            });
        }

        [HttpPost("guess")]
        public async Task<IActionResult> GuessWord([FromBody] GuessDto guessDto)
        {
            int userId = GetUserId();

            if (string.IsNullOrWhiteSpace(guessDto.Word) || guessDto.Word.Length != 5)
                return BadRequest("Guess must be a 5-letter word.");

            var game = await _context.Games
                .Include(g => g.Guesses)
                .FirstOrDefaultAsync(g => g.Id == guessDto.GameId && g.UserId == userId);

            if (game == null)
                return NotFound("Game not found or access denied.");
            if (game.EndDate != null)
                return BadRequest("Game already finished.");
            if (game.Attempts >= 6)
                return BadRequest("No attempts left.");

            string guess = guessDto.Word.ToLower();
            string target = game.TargetWord.ToLower();

            var letterStatuses = new List<LetterStatusDto>();
            var targetChars = target.ToCharArray();
            var guessChars = guess.ToCharArray();
            var matchedIndices = new bool[5];

            for (int i = 0; i < 5; i++)
            {
                if (guessChars[i] == targetChars[i])
                {
                    letterStatuses.Add(new LetterStatusDto { Letter = guessChars[i], Status = "correct" });
                    matchedIndices[i] = true;
                }
                else
                {
                    letterStatuses.Add(null!);
                }
            }

            for (int i = 0; i < 5; i++)
            {
                if (letterStatuses[i] != null) continue;

                bool foundPresent = false;
                for (int j = 0; j < 5; j++)
                {
                    if (!matchedIndices[j] && guessChars[i] == targetChars[j])
                    {
                        foundPresent = true;
                        matchedIndices[j] = true;
                        break;
                    }
                }
                letterStatuses[i] = new LetterStatusDto
                {
                    Letter = guessChars[i],
                    Status = foundPresent ? "present" : "absent"
                };
            }

            game.Attempts++;
            bool isWin = guess == target;

            if (isWin)
            {
                game.IsWin = true;
                game.EndDate = DateTime.UtcNow;

                int points = 10 - (game.Attempts - 1);

                var stat = await _context.Statistics.FirstOrDefaultAsync(s => s.UserId == userId);
                if (stat != null)
                {
                    stat.GamesPlayed++;
                    stat.Wins++;
                    stat.CurrentStreak++;
                    stat.MaxStreak = Math.Max(stat.MaxStreak, stat.CurrentStreak);
                    stat.TotalPoints += points;
                }
            }
            else if (game.Attempts >= 6)
            {
                game.EndDate = DateTime.UtcNow;

                var stat = await _context.Statistics.FirstOrDefaultAsync(s => s.UserId == userId);
                if (stat != null)
                {
                    stat.GamesPlayed++;
                    stat.CurrentStreak = 0;
                }
            }

            var guessRecord = new Guess
            {
                GameId = game.Id,
                Word = guess,
                GuessNumber = game.Attempts,
                GuessResult = string.Join(',', letterStatuses.Select(ls => ls.Status))
            };
            _context.Guesses.Add(guessRecord);

            await _context.SaveChangesAsync();

            return Ok(new GuessResponseDto
            {
                GuessNumber = game.Attempts,
                LetterStatuses = letterStatuses,
                IsWin = isWin,
                IsGameOver = game.EndDate != null,
                Message = isWin ? "Congratulations! You guessed the word." :
                          (game.EndDate != null ? $"Game over! The word was '{target}'." : "Try again.")
            });
        }
        // GET /api/games/stats - Get user game stats
        [HttpGet("stats")]
        public async Task<IActionResult> GetStats()
        {
            var userId = GetUserId();

            var games = await _context.Games
                .Where(g => g.UserId == userId)
                .ToListAsync();

            var totalGames = games.Count;
            var totalWins = games.Count(g => g.IsWin);
            var totalLosses = games.Count(g => g.EndDate != null && !g.IsWin);
            var winPercentage = totalGames > 0 ? Math.Round((double)totalWins / totalGames * 100, 2) : 0;
            var averageAttempts = totalWins > 0 ? Math.Round(games.Where(g => g.IsWin).Average(g => g.Attempts), 2) : 0;
            var lastPlayed = games.Max(g => g.EndDate);

            return Ok(new
            {
                totalGames,
                totalWins,
                totalLosses,
                winPercentage,
                averageAttempts,
                lastPlayed
            });
        }
        // GET /api/games/leaderboard - Top 10 users by wins
        [AllowAnonymous]
        [HttpGet("leaderboard")]
        public async Task<IActionResult> GetLeaderboard()
        {
            var leaderboard = await _context.Games
                .Where(g => g.IsWin)
                .GroupBy(g => g.UserId)
                .Select(group => new
                {
                    UserId = group.Key,
                    Wins = group.Count()
                })
                .OrderByDescending(g => g.Wins)
                .Take(10)
                .Join(_context.Users,
                      g => g.UserId,
                      u => u.Id,
                      (g, u) => new
                      {
                          u.Email,
                          g.Wins
                      })
                .ToListAsync();

            return Ok(leaderboard);
        }


    }
}
