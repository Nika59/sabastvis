﻿public class GuessDto
{
    public int GameId { get; set; }
    public string Word { get; set; } = string.Empty;
}
