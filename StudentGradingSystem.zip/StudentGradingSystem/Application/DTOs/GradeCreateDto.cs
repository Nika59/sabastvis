﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.DTOs
{
    public class GradeCreateDto
    {
        public int StudentId { get; set; }
        public int SubjectId { get; set; }
        public double GradeValue { get; set; }
    }
}
