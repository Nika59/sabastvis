﻿using Application.DTOs;
using Domain.Entities;
using Domain.Interfaces;
using System.Linq;
using System.Threading.Tasks;

namespace Application.Services
{
    public class GradeService
    {
        private readonly IRepository<Grade> _gradeRepo;
        private readonly IRepository<Student> _studentRepo;
        private readonly IRepository<Subject> _subjectRepo;

        public GradeService(
            IRepository<Grade> gradeRepo,
            IRepository<Student> studentRepo,
            IRepository<Subject> subjectRepo)
        {
            _gradeRepo = gradeRepo;
            _studentRepo = studentRepo;
            _subjectRepo = subjectRepo;
        }

        public async Task<string> AddGradeAsync(GradeCreateDto dto)
        {
            if (dto.GradeValue < 0 || dto.GradeValue > 10)
                return "Grade value must be between 0 and 10.";

            var existing = await _gradeRepo.GetAllAsync();
            if (existing.Any(g => g.StudentId == dto.StudentId && g.SubjectId == dto.SubjectId))
                return "A grade for this student and subject already exists.";

            var student = await _studentRepo.GetByIdAsync(dto.StudentId);
            var subject = await _subjectRepo.GetByIdAsync(dto.SubjectId);

            if (student == null || subject == null)
                return "Invalid StudentId or SubjectId.";

            var grade = new Grade
            {
                StudentId = dto.StudentId,
                SubjectId = dto.SubjectId,
                GradeValue = dto.GradeValue
            };

            await _gradeRepo.AddAsync(grade);
            return "Grade added successfully.";
        }
    }
}
