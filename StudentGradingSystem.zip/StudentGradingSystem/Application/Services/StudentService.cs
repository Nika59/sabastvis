﻿using Application.DTOs;
using Domain.Entities;
using Domain.Interfaces;
using System.Threading.Tasks;

namespace Application.Services
{
    public class StudentService
    {
        private readonly IRepository<Student> _studentRepo;

        public StudentService(IRepository<Student> studentRepo)
        {
            _studentRepo = studentRepo;
        }

        public async Task<string> AddStudentAsync(StudentCreateDto dto)
        {
            if (string.IsNullOrEmpty(dto.FullName))
                return "FullName is required";

            var student = new Student
            {
                FullName = dto.FullName,
                BirthDate = dto.BirthDate
            };

            await _studentRepo.AddAsync(student);
            return "Student added successfully.";
        }

        // ✅ Add this method:
        public async Task<StudentWithGradeDto?> GetStudentByIdAsync(int id)
        {
            var student = await _studentRepo.GetByIdAsync(id);
            if (student == null) return null;

            return new StudentWithGradeDto
            {
                FullName = student.FullName,
                Grade = student.Grades != null && student.Grades.Any()
        ? student.Grades.Average(g => g.GradeValue)
        : 0
            };
        }
    }
}
